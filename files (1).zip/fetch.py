"""
Harris County, TX — Motivated Seller Lead Scraper
==================================================
Clerk portal  : https://cclerk.hctx.net/
Parcel data   : HCAD bulk DBF (auto-downloaded)

Usage
-----
    python scraper/fetch.py

Environment variables (optional)
---------------------------------
    LOOKBACK_DAYS   int, default 7
    HCAD_PARCEL_URL direct URL to HCAD parcel zip/dbf (auto-resolved if blank)
"""

from __future__ import annotations

import asyncio
import csv
import json
import logging
import os
import re
import time
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

import requests
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, TimeoutError as PWTimeout

# ── optional dbfread ──────────────────────────────────────────────────────────
try:
    from dbfread import DBF
    HAS_DBF = True
except ImportError:
    HAS_DBF = False
    logging.warning("dbfread not installed – parcel lookup disabled")

# =============================================================================
# CONFIG
# =============================================================================
LOOKBACK_DAYS   = int(os.getenv("LOOKBACK_DAYS", "7"))
CLERK_BASE      = "https://cclerk.hctx.net"
OUTPUT_PATHS    = [
    Path("dashboard/records.json"),
    Path("data/records.json"),
]
GHL_OUTPUT      = Path("data/ghl_export.csv")
PARCEL_CACHE    = Path("data/hcad/real_acct.dbf")

# Instrument codes → (category, human label)
DOC_TYPE_MAP: dict[str, tuple[str, str]] = {
    "LP":       ("LP",      "Lis Pendens"),
    "NOFC":     ("NOFC",    "Notice of Foreclosure"),
    "TAXDEED":  ("TAXDEED", "Tax Deed"),
    "JUD":      ("JUD",     "Judgment"),
    "CCJ":      ("JUD",     "Certified Judgment"),
    "DRJUD":    ("JUD",     "Domestic Judgment"),
    "LNCORPTX": ("LN",     "Corp Tax Lien"),
    "LNIRS":    ("LN",     "IRS Lien"),
    "LNFED":    ("LN",     "Federal Lien"),
    "LN":       ("LN",     "Lien"),
    "LNMECH":   ("LN",     "Mechanic Lien"),
    "LNHOA":    ("LN",     "HOA Lien"),
    "MEDLN":    ("LN",     "Medicaid Lien"),
    "PRO":      ("PRO",    "Probate"),
    "NOC":      ("NOC",    "Notice of Commencement"),
    "RELLP":    ("RELLP",  "Release Lis Pendens"),
}

# =============================================================================
# LOGGING
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

SESSION = requests.Session()
SESSION.headers.update({
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    )
})


# =============================================================================
# UTILITY HELPERS
# =============================================================================

def _normalise_date(raw: str) -> str:
    """Try common date formats → YYYY-MM-DD, or return raw string."""
    for fmt in ("%m/%d/%Y", "%Y-%m-%d", "%m-%d-%Y",
                "%B %d, %Y", "%b %d, %Y", "%d-%b-%Y"):
        try:
            return datetime.strptime(raw.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            pass
    return raw.strip()


def _clean_amount(raw: str) -> float | None:
    s = re.sub(r"[^\d.]", "", raw or "")
    try:
        return float(s) if s else None
    except ValueError:
        return None


# =============================================================================
# PARCEL INDEX  (HCAD bulk DBF)
# =============================================================================

class ParcelIndex:
    """
    Loads the HCAD real-account DBF and indexes records by owner-name
    variants so clerk grantor names can be matched to site/mail addresses.
    """

    # HCAD candidate ZIP URLs tried in order
    _CANDIDATE_ZIPS = [
        "https://pdata.hcad.org/Pdata/real_acct.zip",
        f"https://pdata.hcad.org/download/{datetime.now().year}/real_acct.zip",
        f"https://pdata.hcad.org/download/{datetime.now().year - 1}/real_acct.zip",
        "https://pdata.hcad.org/download/2024/real_acct.zip",
        "https://pdata.hcad.org/download/2023/real_acct.zip",
    ]

    def __init__(self) -> None:
        self._by_name: dict[str, dict] = {}
        self.loaded = False

    # ── public ────────────────────────────────────────────────────────────────

    def load(self, dbf_path: Path | None = None) -> None:
        if not HAS_DBF:
            log.warning("ParcelIndex: dbfread missing – address enrichment disabled")
            return
        path = dbf_path or self._resolve_dbf()
        if not path or not path.exists():
            log.warning("ParcelIndex: no DBF available – address enrichment disabled")
            return
        log.info("Loading parcel DBF from %s …", path)
        try:
            count = 0
            for rec in DBF(str(path), ignore_missing_memofile=True):
                d = {
                    k.upper(): (v.strip() if isinstance(v, str) else (v or ""))
                    for k, v in rec.items()
                }
                owner = (d.get("OWNER") or d.get("OWN1") or "").strip()
                if not owner:
                    continue
                entry = self._make_entry(d)
                for variant in self._name_variants(owner):
                    self._by_name.setdefault(variant, entry)
                count += 1
            self.loaded = True
            log.info("Parcel index ready – %d owners / %d name keys",
                     count, len(self._by_name))
        except Exception as exc:
            log.error("DBF load error: %s", exc)

    def lookup(self, owner_name: str) -> dict | None:
        if not self.loaded or not owner_name:
            return None
        for variant in self._name_variants(owner_name):
            result = self._by_name.get(variant)
            if result:
                return result
        # Fuzzy fallback: strip punctuation
        cleaned = re.sub(r"[^A-Z0-9 ]", "", owner_name.upper()).strip()
        return self._by_name.get(cleaned)

    # ── internals ─────────────────────────────────────────────────────────────

    @staticmethod
    def _make_entry(d: dict) -> dict:
        return {
            "prop_address": (d.get("SITE_ADDR") or d.get("SITEADDR") or "").strip(),
            "prop_city":    (d.get("SITE_CITY") or "").strip(),
            "prop_state":   "TX",
            "prop_zip":     str(d.get("SITE_ZIP") or "").strip(),
            "mail_address": (d.get("ADDR_1") or d.get("MAILADR1") or "").strip(),
            "mail_city":    (d.get("CITY") or d.get("MAILCITY") or "").strip(),
            "mail_state":   (d.get("STATE") or "TX").strip(),
            "mail_zip":     str(d.get("ZIP") or d.get("MAILZIP") or "").strip(),
        }

    @staticmethod
    def _name_variants(name: str) -> list[str]:
        """Return normalised variants: FIRST LAST, LAST FIRST, LAST, FIRST."""
        name = name.strip().upper()
        variants: set[str] = {name}
        # Handle "LAST, FIRST" format
        comma_parts = re.split(r",\s*", name, maxsplit=1)
        if len(comma_parts) == 2:
            last, first = comma_parts[0].strip(), comma_parts[1].strip()
            variants.update({
                f"{first} {last}",
                f"{last} {first}",
                f"{last}, {first}",
                first,
                last,
            })
        else:
            tokens = name.split()
            if len(tokens) >= 2:
                first, last = tokens[0], tokens[-1]
                variants.update({
                    f"{last} {first}",
                    f"{last}, {first}",
                })
        return list(variants)

    def _resolve_dbf(self) -> Path | None:
        """Return cached DBF path, or download + extract from HCAD."""
        if PARCEL_CACHE.exists():
            log.info("Using cached parcel DBF: %s", PARCEL_CACHE)
            return PARCEL_CACHE

        PARCEL_CACHE.parent.mkdir(parents=True, exist_ok=True)
        zip_dest = PARCEL_CACHE.parent / "real_acct.zip"

        for url in self._CANDIDATE_ZIPS:
            log.info("Trying HCAD parcel zip: %s", url)
            try:
                r = SESSION.get(url, timeout=180, stream=True)
                if r.status_code != 200:
                    log.debug("  HTTP %s – skipping", r.status_code)
                    continue
                with open(zip_dest, "wb") as fh:
                    for chunk in r.iter_content(65_536):
                        fh.write(chunk)
                with zipfile.ZipFile(zip_dest) as zf:
                    for member in zf.namelist():
                        if member.lower().endswith(".dbf"):
                            data = zf.read(member)
                            PARCEL_CACHE.write_bytes(data)
                            log.info("  Extracted %s (%d bytes)", member, len(data))
                            return PARCEL_CACHE
            except Exception as exc:
                log.warning("  Download failed: %s", exc)

        log.warning("Could not obtain HCAD DBF; address enrichment disabled")
        return None


# =============================================================================
# SCORING ENGINE
# =============================================================================

def compute_score_and_flags(rec: dict) -> tuple[int, list[str]]:
    """Return (score 0-100, [flag strings])."""
    flags: list[str] = []
    score = 30  # base

    cat      = rec.get("cat", "")
    doc_type = rec.get("doc_type", "")
    amount   = rec.get("amount")
    filed    = rec.get("filed", "")
    owner    = (rec.get("owner") or "").upper()

    # ── assign flags ──────────────────────────────────────────────────────────
    if cat == "LP":
        flags.append("Lis pendens")
    if cat == "NOFC":
        flags.append("Pre-foreclosure")
    if cat == "JUD":
        flags.append("Judgment lien")
    if doc_type in ("LNCORPTX", "LNIRS", "LNFED", "TAXDEED"):
        flags.append("Tax lien")
    if doc_type == "LNMECH":
        flags.append("Mechanic lien")
    if cat == "PRO":
        flags.append("Probate / estate")
    if re.search(r"\b(LLC|INC|CORP|LTD|L\.P\.|TRUST|ASSOC)\b", owner):
        flags.append("LLC / corp owner")

    try:
        filed_dt = datetime.strptime(filed[:10], "%Y-%m-%d")
        if (datetime.now() - filed_dt).days <= 7:
            flags.append("New this week")
    except Exception:
        pass

    # ── build score ───────────────────────────────────────────────────────────
    score += len(flags) * 10

    if "Lis pendens" in flags and "Pre-foreclosure" in flags:
        score += 20

    try:
        amt = float(amount)
        if amt > 100_000:
            score += 15
        elif amt > 50_000:
            score += 10
    except (TypeError, ValueError):
        pass

    if "New this week" in flags:
        score += 5

    if rec.get("prop_address") or rec.get("mail_address"):
        score += 5

    return min(score, 100), flags


# =============================================================================
# CLERK PORTAL SCRAPER  (Playwright async)
# =============================================================================

async def scrape_clerk(
    doc_types: list[str],
    date_from: str,
    date_to: str,
    max_retries: int = 3,
) -> list[dict]:
    """
    Scrape Harris County Clerk official records for all doc types in the
    given date range.  Returns a flat list of raw record dicts.
    """
    all_records: list[dict] = []

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        ctx = await browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent=(
                "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            ),
        )
        page = await ctx.new_page()

        for dtype in doc_types:
            log.info("  Clerk search: %s", dtype)
            for attempt in range(1, max_retries + 1):
                try:
                    recs = await _search_instrument_type(
                        page, dtype, date_from, date_to
                    )
                    all_records.extend(recs)
                    log.info("    → %d records", len(recs))
                    break
                except PWTimeout:
                    log.warning("    Timeout (attempt %d/%d)", attempt, max_retries)
                except Exception as exc:
                    log.warning("    Error (attempt %d/%d): %s", attempt, max_retries, exc)

                if attempt < max_retries:
                    await asyncio.sleep(3 * attempt)
                else:
                    log.error("    %s: all retries exhausted", dtype)

        await browser.close()

    return all_records


async def _search_instrument_type(
    page, dtype: str, date_from: str, date_to: str
) -> list[dict]:
    """
    Navigate to the Harris County Clerk official records search page,
    fill in document type + date range, and collect all paginated results.

    The portal (https://cclerk.hctx.net/web/search.aspx) uses ASP.NET
    WebForms; pagination uses __doPostBack targets.
    """
    SEARCH_URL = f"{CLERK_BASE}/web/search.aspx"

    # ── load search page ──────────────────────────────────────────────────────
    await page.goto(SEARCH_URL, timeout=30_000, wait_until="domcontentloaded")
    await page.wait_for_timeout(1_500)

    # ── instrument type ───────────────────────────────────────────────────────
    # Try <select> first, then text <input>
    filled = False
    for sel in [
        'select[id*="ddlInstrumentType"]', 'select[name*="InstrumentType"]',
        'select[id*="Instrument"]',         'select[id*="instrument"]',
    ]:
        try:
            if await page.locator(sel).count():
                await page.select_option(sel, value=dtype, timeout=4_000)
                filled = True
                break
        except Exception:
            pass

    if not filled:
        for sel in [
            'input[id*="InstrumentType"]', 'input[name*="InstrumentType"]',
            'input[id*="txtInstrument"]',  'input[id*="instrument"]',
        ]:
            try:
                if await page.locator(sel).count():
                    await page.fill(sel, dtype, timeout=4_000)
                    filled = True
                    break
            except Exception:
                pass

    # ── date from ─────────────────────────────────────────────────────────────
    for sel in [
        'input[id*="StartDate"]',  'input[name*="StartDate"]',
        'input[id*="DateFrom"]',   'input[name*="DateFrom"]',
        'input[id*="BeginDate"]',  'input[name*="BeginDate"]',
        'input[id*="FiledFrom"]',  'input[name*="FiledFrom"]',
    ]:
        try:
            if await page.locator(sel).count():
                await page.fill(sel, date_from, timeout=4_000)
                break
        except Exception:
            pass

    # ── date to ───────────────────────────────────────────────────────────────
    for sel in [
        'input[id*="EndDate"]',   'input[name*="EndDate"]',
        'input[id*="DateTo"]',    'input[name*="DateTo"]',
        'input[id*="StopDate"]',  'input[name*="StopDate"]',
        'input[id*="FiledTo"]',   'input[name*="FiledTo"]',
    ]:
        try:
            if await page.locator(sel).count():
                await page.fill(sel, date_to, timeout=4_000)
                break
        except Exception:
            pass

    # ── submit ────────────────────────────────────────────────────────────────
    submitted = False
    for sel in [
        '#btnSearch', 'input[id*="btnSearch"]', 'button[id*="btnSearch"]',
        'input[value="Search"]', 'button[type="submit"]',
        'input[type="submit"]',  '#SearchButton', '.btn-search',
    ]:
        try:
            if await page.locator(sel).count():
                await page.click(sel, timeout=5_000)
                submitted = True
                break
        except Exception:
            pass

    if not submitted:
        await page.keyboard.press("Enter")

    await page.wait_for_load_state("networkidle", timeout=25_000)

    # ── collect paginated results ─────────────────────────────────────────────
    records: list[dict] = []
    page_num = 0

    while True:
        page_num += 1
        html = await page.content()
        batch = _parse_result_table(html, dtype)
        records.extend(batch)
        log.debug("      page %d → %d rows", page_num, len(batch))

        if page_num >= 100:  # safety limit
            break

        # Look for a "Next" link (text-based and aria-based)
        next_loc = page.locator(
            'a:text("Next"), a:text(">"), a:text("»"), '
            'input[value="Next"], a[title="Next Page"], '
            '.pagerNext, #lnkNext, [aria-label="Next page"]'
        ).first
        try:
            if not await next_loc.is_visible(timeout=2_000):
                break
            await next_loc.click(timeout=8_000)
            await page.wait_for_load_state("networkidle", timeout=20_000)
        except Exception:
            break

    return records


def _parse_result_table(html: str, dtype: str) -> list[dict]:
    """Parse the HTML results table; detect columns dynamically."""
    soup = BeautifulSoup(html, "lxml")
    records: list[dict] = []

    # Find the best candidate table
    table = None
    for t in soup.find_all("table"):
        tid  = (t.get("id") or "").lower()
        tcls = " ".join(t.get("class") or []).lower()
        if any(kw in tid + tcls for kw in ("result", "grid", "data", "search", "record")):
            table = t
            break
    if not table:
        all_tables = soup.find_all("table")
        if not all_tables:
            return records
        table = max(all_tables, key=lambda t: len(t.find_all("tr")))

    rows = table.find_all("tr")
    if len(rows) < 2:
        return records

    # Detect header columns
    header_row = rows[0]
    headers = [
        th.get_text(" ", strip=True).upper()
        for th in header_row.find_all(["th", "td"])
    ]

    def _col(cells: list, *keywords: str) -> str:
        for kw in keywords:
            for i, h in enumerate(headers):
                if kw in h and i < len(cells):
                    return cells[i].get_text(" ", strip=True)
        return ""

    cat, cat_label = DOC_TYPE_MAP.get(dtype, (dtype, dtype))

    for row in rows[1:]:
        cells = row.find_all(["td", "th"])
        if not cells or len(cells) < 2:
            continue
        try:
            doc_num = _col(cells, "DOC", "INSTRUMENT", "BOOK", "NUMBER", "RECORD #")
            filed   = _col(cells, "FILE DATE", "RECORD DATE", "DATE", "FILED", "STAMP")
            grantor = _col(cells, "GRANTOR", "OWNER", "FROM", "SELLER")
            grantee = _col(cells, "GRANTEE", "TO", "LENDER", "BUYER", "BANK")
            legal   = _col(cells, "LEGAL", "DESCR", "SUBDIV", "PROPERTY")
            amount  = _col(cells, "AMOUNT", "CONSID", "DEBT", "FACE VALUE")

            # Extract hyperlink from row
            href = ""
            link_tag = row.find("a", href=True)
            if link_tag:
                raw = link_tag["href"]
                href = raw if raw.startswith("http") else f"{CLERK_BASE}/{raw.lstrip('/')}"
                if not doc_num:
                    doc_num = link_tag.get_text(strip=True)

            if not doc_num and not grantor:
                continue  # blank row

            records.append({
                "doc_num":      doc_num.strip(),
                "doc_type":     dtype,
                "filed":        _normalise_date(filed) if filed else "",
                "cat":          cat,
                "cat_label":    cat_label,
                "owner":        grantor.strip(),
                "grantee":      grantee.strip(),
                "amount":       _clean_amount(amount),
                "legal":        legal.strip(),
                "clerk_url":    href,
                # addresses populated later
                "prop_address": "",
                "prop_city":    "",
                "prop_state":   "TX",
                "prop_zip":     "",
                "mail_address": "",
                "mail_city":    "",
                "mail_state":   "TX",
                "mail_zip":     "",
            })
        except Exception as exc:
            log.debug("Row parse error: %s", exc)

    return records


# =============================================================================
# ENRICHMENT  (parcel lookup + scoring)
# =============================================================================

def enrich_records(records: list[dict], parcel: ParcelIndex) -> list[dict]:
    out: list[dict] = []
    for rec in records:
        try:
            pdata = parcel.lookup(rec.get("owner", ""))
            if pdata:
                rec.update(pdata)
            score, flags = compute_score_and_flags(rec)
            rec["score"] = score
            rec["flags"] = flags
        except Exception as exc:
            log.debug("Enrich error %s: %s", rec.get("doc_num"), exc)
            rec.setdefault("score", 30)
            rec.setdefault("flags", [])
        out.append(rec)
    return out


# =============================================================================
# DEDUPLICATION
# =============================================================================

def deduplicate(records: list[dict]) -> list[dict]:
    seen: set[str] = set()
    out: list[dict] = []
    for r in records:
        key = f"{r.get('doc_num')}|{r.get('doc_type')}|{r.get('filed')}"
        if key not in seen:
            seen.add(key)
            out.append(r)
    return out


# =============================================================================
# OUTPUT
# =============================================================================

def save_json(records: list[dict], date_from: str, date_to: str) -> None:
    payload = {
        "fetched_at":   datetime.utcnow().isoformat() + "Z",
        "source":       "Harris County Clerk – cclerk.hctx.net",
        "date_range":   {"from": date_from, "to": date_to},
        "total":        len(records),
        "with_address": sum(
            1 for r in records
            if r.get("prop_address") or r.get("mail_address")
        ),
        "records": records,
    }
    for path in OUTPUT_PATHS:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(payload, indent=2, default=str),
            encoding="utf-8",
        )
        log.info("Saved JSON → %s  (%d records)", path, len(records))


def save_ghl_csv(records: list[dict]) -> None:
    GHL_OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "First Name", "Last Name",
        "Mailing Address", "Mailing City", "Mailing State", "Mailing Zip",
        "Property Address", "Property City", "Property State", "Property Zip",
        "Lead Type", "Document Type", "Date Filed", "Document Number",
        "Amount/Debt Owed", "Seller Score", "Motivated Seller Flags",
        "Source", "Public Records URL",
    ]
    with open(GHL_OUTPUT, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for rec in records:
            owner_raw = re.sub(r"[,]+", " ", (rec.get("owner") or "")).strip()
            parts = owner_raw.split(None, 1)
            first = parts[0] if parts else ""
            last  = parts[1] if len(parts) > 1 else ""
            writer.writerow({
                "First Name":             first,
                "Last Name":              last,
                "Mailing Address":        rec.get("mail_address", ""),
                "Mailing City":           rec.get("mail_city", ""),
                "Mailing State":          rec.get("mail_state", "TX"),
                "Mailing Zip":            rec.get("mail_zip", ""),
                "Property Address":       rec.get("prop_address", ""),
                "Property City":          rec.get("prop_city", ""),
                "Property State":         rec.get("prop_state", "TX"),
                "Property Zip":           rec.get("prop_zip", ""),
                "Lead Type":              rec.get("cat_label", ""),
                "Document Type":          rec.get("doc_type", ""),
                "Date Filed":             rec.get("filed", ""),
                "Document Number":        rec.get("doc_num", ""),
                "Amount/Debt Owed":       rec.get("amount") or "",
                "Seller Score":           rec.get("score", 30),
                "Motivated Seller Flags": "; ".join(rec.get("flags", [])),
                "Source":                 "Harris County Clerk",
                "Public Records URL":     rec.get("clerk_url", ""),
            })
    log.info("GHL CSV → %s  (%d rows)", GHL_OUTPUT, len(records))


# =============================================================================
# MAIN
# =============================================================================

async def main() -> None:
    now       = datetime.now()
    date_to   = now.strftime("%m/%d/%Y")
    date_from = (now - timedelta(days=LOOKBACK_DAYS)).strftime("%m/%d/%Y")

    log.info("=" * 60)
    log.info("Harris County Motivated Seller Scraper")
    log.info("Lookback : %d days  |  %s → %s", LOOKBACK_DAYS, date_from, date_to)
    log.info("Doc types: %d", len(DOC_TYPE_MAP))
    log.info("=" * 60)

    # 1. Parcel index
    parcel = ParcelIndex()
    parcel.load()

    # 2. Clerk scrape
    log.info("Scraping Harris County Clerk portal …")
    raw = await scrape_clerk(
        doc_types=list(DOC_TYPE_MAP.keys()),
        date_from=date_from,
        date_to=date_to,
    )
    log.info("Raw records: %d", len(raw))

    # 3. Deduplicate
    unique = deduplicate(raw)
    log.info("After dedup: %d", len(unique))

    # 4. Enrich
    enriched = enrich_records(unique, parcel)

    # 5. Sort by score descending
    enriched.sort(key=lambda r: r.get("score", 0), reverse=True)

    # 6. Write outputs
    date_from_iso = datetime.strptime(date_from, "%m/%d/%Y").strftime("%Y-%m-%d")
    date_to_iso   = datetime.strptime(date_to,   "%m/%d/%Y").strftime("%Y-%m-%d")
    save_json(enriched, date_from_iso, date_to_iso)
    save_ghl_csv(enriched)

    # 7. Summary
    with_addr  = sum(1 for r in enriched if r.get("prop_address") or r.get("mail_address"))
    high_score = sum(1 for r in enriched if (r.get("score") or 0) >= 70)
    log.info("-" * 60)
    log.info("Total leads    : %d", len(enriched))
    log.info("With address   : %d", with_addr)
    log.info("High score ≥70 : %d", high_score)
    if enriched:
        top = enriched[0]
        log.info("Top lead       : %s  score=%s  flags=%s",
                 top.get("owner"), top.get("score"), top.get("flags"))
    log.info("Done ✓")


if __name__ == "__main__":
    asyncio.run(main())
